
//jQuery for Active click menu

$("li.active_click" ).click(function() {
    alert("you clicked me");
});

